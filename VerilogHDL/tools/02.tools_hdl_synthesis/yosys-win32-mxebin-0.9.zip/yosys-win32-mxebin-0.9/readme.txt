-en This is Yosys 0.9 for Win32.

-en Documentation at http://www.clifford.at/yosys/.

